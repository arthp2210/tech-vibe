import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  ActivityIndicator,
  Linking,
  TextInput,
  Modal,
  Dimensions,
  ImageBackground,
} from "react-native";
import { Ionicons, MaterialIcons, FontAwesome5 } from "@expo/vector-icons";
import { LinearGradient } from 'expo-linear-gradient';
import DateTimePicker from '@react-native-community/datetimepicker';
import axios from "axios";
import ApiService from "../../services/api";

const { width } = Dimensions.get('window');

const Events = () => {
  const [events, setEvents] = useState([]);
  const [respondingTo, setRespondingTo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    location: "",
    date: new Date(),
    time: new Date(),
    tags: "",
    image: "",
  });

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const res = await axios.get(ApiService.GET_EVENTS);
        setEvents(res.data);
      } catch (error) {
        Alert.alert("Error", "Failed to fetch events from the server.");
      } finally {
        setLoading(false);
      }
    };

    fetchEvents();
  }, []);

  // Reset form when modal opens
  useEffect(() => {
    if (modalVisible) {
      const today = new Date();
      setForm((prev) => ({
        ...prev,
        date: today,
        time: today,
      }));
    }
  }, [modalVisible]);

  const handleRSVP = async (eventId, status) => {
    try {
      await axios.post(ApiService.POST_RSVP, {
        eventId,
        status,
      });
      Alert.alert("RSVP Submitted", `You marked yourself as "${status}"`);
      setRespondingTo(null);
    } catch (err) {
      Alert.alert("RSVP Failed", "An error occurred. Please try again.");
    }
  };

  const openGoogleMaps = (location) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
      location
    )}`;
    Linking.openURL(url);
  };

  const handleFormChange = (field, value) => {
    setForm({ ...form, [field]: value });
  };

  const onDateChange = (event, selectedDate) => {
    setShowDatePicker(false);
    if (selectedDate) {
      setForm({ ...form, date: selectedDate });
    }
  };

  const onTimeChange = (event, selectedTime) => {
    setShowTimePicker(false);
    if (selectedTime) {
      setForm({ ...form, time: selectedTime });
    }
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatTime = (time) => {
    return time.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const combineDateTime = (date, time) => {
    const combined = new Date(date);
    combined.setHours(time.getHours());
    combined.setMinutes(time.getMinutes());
    return combined;
  };

  const handleCreateEvent = async () => {
    if (!form.title || !form.date) {
      Alert.alert("Validation", "Title and Date are required");
      return;
    }

    const tagsArray = form.tags
      .split(",")
      .map((tag) => tag.trim())
      .filter((tag) => tag.length > 0);

    try {
      const eventDateTime = combineDateTime(form.date, form.time);
      const newEvent = {
        title: form.title,
        description: form.description,
        location: form.location,
        date: eventDateTime.toISOString(),
        tags: tagsArray,
        image: form.image,
      };
      const res = await axios.post(ApiService.POST_EVENT, newEvent);
      setEvents([res.data, ...events]);
      setModalVisible(false);
      setForm({
        title: "",
        description: "",
        location: "",
        date: new Date(),
        time: new Date(),
        tags: "",
        image: "",
      });
      Alert.alert("Success", "Event created successfully");
    } catch (error) {
      Alert.alert("Error", "Failed to create event");
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'going': return 'checkmark-circle';
      case 'interested': return 'star';
      case 'not going': return 'close-circle';
      default: return 'help-circle';
    }
  };

  if (loading) {
    return (
      <LinearGradient colors={['#0f0c29', '#302b63', '#24243e']} style={styles.loadingContainer}>
        <View style={styles.loadingContent}>
          <ActivityIndicator size="large" color="#00d4ff" />
          <Text style={styles.loadingText}>Loading Events...</Text>
          <View style={styles.loadingDots}>
            <View style={[styles.dot, { animationDelay: 0 }]} />
            <View style={[styles.dot, { animationDelay: 0.2 }]} />
            <View style={[styles.dot, { animationDelay: 0.4 }]} />
          </View>
        </View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient colors={['#0f0c29', '#302b63', '#24243e']} style={styles.container}>
      {/* Header Section */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.headerTitle}>Tech Events 🎯</Text>
            <Text style={styles.headerSubtitle}>Manage and discover events</Text>
          </View>
          
          <TouchableOpacity
            style={styles.createButton}
            onPress={() => setModalVisible(true)}
          >
            <LinearGradient colors={['#667eea', '#764ba2']} style={styles.createButtonGradient}>
              <Ionicons name="add" size={20} color="white" />
              <Text style={styles.createButtonText}>Create</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <FontAwesome5 name="calendar-check" size={16} color="#00d4ff" />
            <Text style={styles.statNumber}>{events.length}</Text>
            <Text style={styles.statLabel}>Total Events</Text>
          </View>
          <View style={styles.statCard}>
            <FontAwesome5 name="clock" size={16} color="#ff6b6b" />
            <Text style={styles.statNumber}>
              {events.filter(e => new Date(e.date) >= new Date()).length}
            </Text>
            <Text style={styles.statLabel}>Upcoming</Text>
          </View>
        </View>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.eventsContainer}>
          {events.map((event, index) => (
            <View key={event._id} style={[styles.eventCard, { marginTop: index === 0 ? 0 : 20 }]}>
              {/* Event Image */}
              {event.image ? (
                <ImageBackground source={{ uri: event.image }} style={styles.eventImage}>
                  <LinearGradient 
                    colors={['transparent', 'rgba(0,0,0,0.8)']} 
                    style={styles.imageOverlay}
                  >
                    <View style={styles.datebadge}>
                      <Text style={styles.dateBadgeText}>
                        {new Date(event.date).getDate()}
                      </Text>
                      <Text style={styles.dateBadgeMonth}>
                        {new Date(event.date).toLocaleDateString('en', { month: 'short' })}
                      </Text>
                    </View>
                  </LinearGradient>
                </ImageBackground>
              ) : (
                <View style={styles.placeholderImage}>
                  <LinearGradient colors={['#667eea', '#764ba2']} style={styles.placeholderGradient}>
                    <FontAwesome5 name="calendar-alt" size={40} color="white" />
                  </LinearGradient>
                </View>
              )}

              {/* Event Content */}
              <View style={styles.eventContent}>
                <Text style={styles.eventTitle}>{event.title}</Text>
                
                {event.description && (
                  <View style={styles.eventDetail}>
                    <Ionicons name="document-text-outline" size={16} color="#00d4ff" />
                    <Text style={styles.eventDescription}>{event.description}</Text>
                  </View>
                )}

                <View style={styles.eventDetails}>
                  {event.location && (
                    <View style={styles.eventDetail}>
                      <Ionicons name="location-outline" size={16} color="#ff6b6b" />
                      <Text style={styles.eventDetailText}>{event.location}</Text>
                    </View>
                  )}

                  <View style={styles.eventDetail}>
                    <Ionicons name="calendar-outline" size={16} color="#4ecdc4" />
                    <Text style={styles.eventDetailText}>
                      {new Date(event.date).toDateString()}
                    </Text>
                  </View>

                  {event.tags && event.tags.length > 0 && (
                    <View style={styles.tagsContainer}>
                      <Ionicons name="pricetags-outline" size={16} color="#a855f7" />
                      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        <View style={styles.tagsRow}>
                          {event.tags.map((tag, tagIndex) => (
                            <View key={tagIndex} style={styles.tagChip}>
                              <Text style={styles.tagText}>{tag}</Text>
                            </View>
                          ))}
                        </View>
                      </ScrollView>
                    </View>
                  )}
                </View>

                {/* Action Buttons */}
                <View style={styles.actionSection}>
                  {event.location && (
                    <TouchableOpacity
                      style={styles.directionsButton}
                      onPress={() => openGoogleMaps(event.location)}
                    >
                      <Ionicons name="navigate" size={16} color="#00d4ff" />
                      <Text style={styles.directionsButtonText}>Directions</Text>
                    </TouchableOpacity>
                  )}

                  {respondingTo === event._id ? (
                    <View style={styles.rsvpOptions}>
                      <TouchableOpacity
                        style={[styles.rsvpButton, styles.goingButton]}
                        onPress={() => handleRSVP(event._id, "going")}
                      >
                        <Ionicons name="checkmark-circle" size={16} color="white" />
                        <Text style={styles.rsvpButtonText}>Going</Text>
                      </TouchableOpacity>
                      
                      <TouchableOpacity
                        style={[styles.rsvpButton, styles.interestedButton]}
                        onPress={() => handleRSVP(event._id, "interested")}
                      >
                        <Ionicons name="star" size={16} color="white" />
                        <Text style={styles.rsvpButtonText}>Interested</Text>
                      </TouchableOpacity>
                      
                      <TouchableOpacity
                        style={[styles.rsvpButton, styles.notGoingButton]}
                        onPress={() => handleRSVP(event._id, "not going")}
                      >
                        <Ionicons name="close-circle" size={16} color="white" />
                        <Text style={styles.rsvpButtonText}>Not Going</Text>
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <TouchableOpacity
                      style={styles.respondButton}
                      onPress={() => setRespondingTo(event._id)}
                    >
                      <LinearGradient colors={['#f093fb', '#f5576c']} style={styles.respondButtonGradient}>
                        <Ionicons name="checkmark-circle-outline" size={16} color="white" />
                        <Text style={styles.respondButtonText}>Respond</Text>
                      </LinearGradient>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            </View>
          ))}
        </View>
        
        <View style={styles.footer} />
      </ScrollView>

      {/* Create Event Modal */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalContainer}>
            <LinearGradient colors={['#667eea', '#764ba2']} style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Create New Event</Text>
              <TouchableOpacity
                style={styles.modalCloseButton}
                onPress={() => setModalVisible(false)}
              >
                <Ionicons name="close" size={24} color="white" />
              </TouchableOpacity>
            </LinearGradient>

            <ScrollView style={styles.modalContent} showsVerticalScrollIndicator={false}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Title *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter event title"
                  placeholderTextColor="#a0a9c0"
                  value={form.title}
                  onChangeText={(text) => handleFormChange("title", text)}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Description</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Describe your event"
                  placeholderTextColor="#a0a9c0"
                  value={form.description}
                  onChangeText={(text) => handleFormChange("description", text)}
                  multiline
                  numberOfLines={3}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Location</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Event location"
                  placeholderTextColor="#a0a9c0"
                  value={form.location}
                  onChangeText={(text) => handleFormChange("location", text)}
                />
              </View>

              {/* Date & Time Section */}
              <View style={styles.dateTimeContainer}>
                <View style={styles.dateTimeRow}>
                  <View style={styles.dateTimeGroup}>
                    <Text style={styles.inputLabel}>Date *</Text>
                    <TouchableOpacity
                      style={styles.dateTimeButton}
                      onPress={() => setShowDatePicker(true)}
                    >
                      <Ionicons name="calendar-outline" size={20} color="#00d4ff" />
                      <Text style={styles.dateTimeButtonText}>
                        {formatDate(form.date)}
                      </Text>
                    </TouchableOpacity>
                  </View>

                  <View style={styles.dateTimeGroup}>
                    <Text style={styles.inputLabel}>Time</Text>
                    <TouchableOpacity
                      style={styles.dateTimeButton}
                      onPress={() => setShowTimePicker(true)}
                    >
                      <Ionicons name="time-outline" size={20} color="#ff6b6b" />
                      <Text style={styles.dateTimeButtonText}>
                        {formatTime(form.time)}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>

                {/* Date Picker */}
                {showDatePicker && (
                  <DateTimePicker
                    value={form.date}
                    mode="date"
                    display="default"
                    onChange={onDateChange}
                    minimumDate={new Date()}
                  />
                )}

                {/* Time Picker */}
                {showTimePicker && (
                  <DateTimePicker
                    value={form.time}
                    mode="time"
                    display="default"
                    onChange={onTimeChange}
                  />
                )}
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Tags</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter tags separated by commas"
                  placeholderTextColor="#a0a9c0"
                  value={form.tags}
                  onChangeText={(text) => handleFormChange("tags", text)}
                />
                <Text style={styles.helperText}>
                  e.g., Tech, Conference, Networking, Workshop
                </Text>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Image URL</Text>
                <TextInput
                  style={styles.input}
                  placeholder="https://example.com/image.jpg"
                  placeholderTextColor="#a0a9c0"
                  value={form.image}
                  onChangeText={(text) => handleFormChange("image", text)}
                />
                {form.image ? (
                  <Image
                    source={{ uri: form.image }}
                    style={styles.imagePreview}
                    onError={() => Alert.alert("Invalid Image URL", "Please check the image URL")}
                  />
                ) : null}
              </View>

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.modalCreateButton}
                  onPress={handleCreateEvent}
                >
                  <LinearGradient colors={['#4facfe', '#00f2fe']} style={styles.modalCreateButtonGradient}>
                    <Ionicons name="add-circle-outline" size={20} color="white" />
                    <Text style={styles.modalCreateButtonText}>Create Event</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingContent: {
    alignItems: 'center',
  },
  loadingText: {
    color: '#fff',
    fontSize: 16,
    marginTop: 15,
    fontWeight: '500',
  },
  loadingDots: {
    flexDirection: 'row',
    marginTop: 10,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#00d4ff',
    marginHorizontal: 3,
  },

  // Header Styles
  header: {
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#ffffff",
    marginBottom: 5,
  },
  headerSubtitle: {
    fontSize: 16,
    color: "#a0a9c0",
  },
  createButton: {
    marginTop: 5,
  },
  createButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 25,
  },
  createButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
    marginLeft: 6,
  },

  // Stats
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 15,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 5,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#a0a9c0',
  },

  // Events
  scrollView: {
    flex: 1,
  },
  eventsContainer: {
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  eventCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    overflow: "hidden",
    backdropFilter: 'blur(10px)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  eventImage: {
    width: "100%",
    height: 180,
  },
  imageOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
    padding: 15,
  },
  datebadge: {
    backgroundColor: 'rgba(0,212,255,0.9)',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    alignItems: 'center',
  },
  dateBadgeText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  dateBadgeMonth: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  placeholderImage: {
    width: "100%",
    height: 180,
  },
  placeholderGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Event Content
  eventContent: {
    padding: 20,
  },
  eventTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#ffffff",
    marginBottom: 15,
  },
  eventDetails: {
    marginBottom: 20,
  },
  eventDetail: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 8,
  },
  eventDescription: {
    color: "#a0a9c0",
    marginLeft: 10,
    fontSize: 14,
    flex: 1,
  },
  eventDetailText: {
    color: "#a0a9c0",
    marginLeft: 10,
    fontSize: 14,
    fontWeight: '500',
  },

  // Tags
  tagsContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
  },
  tagsRow: {
    flexDirection: 'row',
    marginLeft: 10,
  },
  tagChip: {
    backgroundColor: 'rgba(168, 85, 247, 0.2)',
    borderColor: '#a855f7',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginRight: 6,
  },
  tagText: {
    color: '#a855f7',
    fontSize: 12,
    fontWeight: '600',
  },

  // Action Buttons
  actionSection: {
    gap: 12,
  },
  directionsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,212,255,0.2)',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#00d4ff',
  },
  directionsButtonText: {
    color: "#00d4ff",
    fontWeight: "600",
    fontSize: 14,
    marginLeft: 6,
  },
  respondButton: {
    alignSelf: 'stretch',
  },
  respondButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 25,
  },
  respondButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
    marginLeft: 6,
  },

  // RSVP Options
  rsvpOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8,
  },
  rsvpButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 20,
  },
  goingButton: {
    backgroundColor: '#22c55e',
  },
  interestedButton: {
    backgroundColor: '#facc15',
  },
  notGoingButton: {
    backgroundColor: '#ef4444',
  },
  rsvpButtonText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 12,
    marginLeft: 4,
  },

  // Modal Styles
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.8)",
    justifyContent: "flex-end",
  },
  modalContainer: {
    backgroundColor: "#1a1a2e",
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    maxHeight: '90%',
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#ffffff",
  },
  modalCloseButton: {
    padding: 5,
  },
  modalContent: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    color: '#ffffff',
    borderRadius: 12,
    padding: 15,
    fontSize: 16,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  helperText: {
    fontSize: 12,
    color: '#a0a9c0',
    marginTop: 5,
  },

  // Date Time Picker Styles
  dateTimeContainer: {
    marginBottom: 20,
  },
  dateTimeRow: {
    flexDirection: 'row',
    gap: 12,
  },
  dateTimeGroup: {
    flex: 1,
  },
  dateTimeButton: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    borderRadius: 12,
    padding: 15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  dateTimeButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '500',
  },

  imagePreview: {
    width: 120,
    height: 80,
    borderRadius: 12,
    marginTop: 10,
    alignSelf: 'center',
  },
  modalButtons: {
    marginTop: 20,
  },
  modalCreateButton: {
    alignSelf: 'stretch',
  },
  modalCreateButtonGradient: {
    flexDirection: 'row',
    paddingVertical: 16,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  modalCreateButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 18,
  },

  footer: {
    height: 40,
  },
});

export default Events;