import { Tabs } from "expo-router";
import { MaterialIcons, Ionicons, Entypo } from "@expo/vector-icons";

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: "#0ea5e9",
        tabBarInactiveTintColor: "#94a3b8",
        tabBarStyle: {
          backgroundColor: "#1e293b",
          height: 60,
          paddingBottom: 8,
          paddingTop: 8,
          borderTopWidth: 0,
        },
        tabBarIcon: ({ color, size }) => {
          if (route.name === "home") {
            return <MaterialIcons name="home-filled" size={size} color={color} />;
          } else if (route.name === "events") {
            return <Ionicons name="ios-calendar" size={size} color={color} />;
          } else if (route.name === "profile") {
            return <Entypo name="user" size={size} color={color} />;
          } else if (route.name === "settings") {
            return <Ionicons name="settings-sharp" size={size} color={color} />;
          }
        },
      })}
    />
  );
}
