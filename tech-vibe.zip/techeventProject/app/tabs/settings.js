import React, { useState } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  Switch,
  SafeAreaView,
  Modal,
  ScrollView,
  Alert,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";

const LANGUAGES = [
  { code: "en", label: "English" },
  { code: "es", label: "Spanish" },
  { code: "fr", label: "French" },
  { code: "de", label: "German" },
];

export default function Settings() {
  const router = useRouter();

  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [locationAccessEnabled, setLocationAccessEnabled] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState(LANGUAGES[0]);
  const [logoutModalVisible, setLogoutModalVisible] = useState(false);

  const toggleNotifications = () => setNotificationsEnabled((prev) => !prev);
  const toggleLocationAccess = () => setLocationAccessEnabled((prev) => !prev);

  const logout = async () => {
    try {
      await AsyncStorage.removeItem("token");
      await AsyncStorage.removeItem("isLoggedIn");
      setLogoutModalVisible(true);
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  const showLanguageAlert = () => {
    const languageOptions = LANGUAGES.map(lang => ({
      text: lang.label,
      onPress: () => setSelectedLanguage(lang)
    }));

    Alert.alert(
      "Select Language",
      "Choose your preferred language:",
      [
        ...languageOptions,
        {
          text: "Cancel",
          style: "cancel"
        }
      ]
    );
  };

  const showPrivacyAlert = () => {
    Alert.alert(
      "Privacy Policy",
      "Your privacy is important to us. We collect and use personal data only to provide and improve our services. We do not share your information with third parties without your consent.\n\nWe use cookies and tracking technologies to personalize your experience. You can control these settings in your browser or device preferences.\n\nFor more details, please contact support@example.com.",
      [
        {
          text: "OK",
          style: "default"
        }
      ]
    );
  };

  const dynamicStyles = getDynamicStyles(false);

  return (
    <SafeAreaView style={[styles.container, dynamicStyles.container]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Header Section */}
      

        {/* Settings Sections */}
        <View style={[styles.settingsContainer, dynamicStyles.settingsContainer]}>
          
          {/* Preferences Section */}
          <View style={[styles.section, dynamicStyles.section]}>
            <Text style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>Preferences</Text>
            
            <View style={[styles.settingItem, dynamicStyles.settingItem]}>
              <View style={styles.settingLeft}>
                <View style={[styles.iconContainer, { backgroundColor: '#10b981' }]}>
                  <Text style={styles.iconText}>🔔</Text>
                </View>
                <View style={styles.settingTextContainer}>
                  <Text style={[styles.settingTitle, dynamicStyles.text]}>Notifications</Text>
                  <Text style={[styles.settingSubtitle, dynamicStyles.subtitleText]}>
                    Push notifications and alerts
                  </Text>
                </View>
              </View>
              <Switch
                trackColor={{ false: "#374151", true: "#10b981" }}
                thumbColor={notificationsEnabled ? "#ffffff" : "#9ca3af"}
                onValueChange={toggleNotifications}
                value={notificationsEnabled}
                style={styles.switch}
              />
            </View>

            <View style={[styles.settingItem, dynamicStyles.settingItem]}>
              <View style={styles.settingLeft}>
                <View style={[styles.iconContainer, { backgroundColor: '#f59e0b' }]}>
                  <Text style={styles.iconText}>📍</Text>
                </View>
                <View style={styles.settingTextContainer}>
                  <Text style={[styles.settingTitle, dynamicStyles.text]}>Location Access</Text>
                  <Text style={[styles.settingSubtitle, dynamicStyles.subtitleText]}>
                    Allow location-based features
                  </Text>
                </View>
              </View>
              <Switch
                trackColor={{ false: "#374151", true: "#f59e0b" }}
                thumbColor={locationAccessEnabled ? "#ffffff" : "#9ca3af"}
                onValueChange={toggleLocationAccess}
                value={locationAccessEnabled}
                style={styles.switch}
              />
            </View>

            <Pressable 
              style={[styles.settingItem, dynamicStyles.settingItem]} 
              onPress={showLanguageAlert}
            >
              <View style={styles.settingLeft}>
                <View style={[styles.iconContainer, { backgroundColor: '#8b5cf6' }]}>
                  <Text style={styles.iconText}>🌐</Text>
                </View>
                <View style={styles.settingTextContainer}>
                  <Text style={[styles.settingTitle, dynamicStyles.text]}>Language</Text>
                  <Text style={[styles.settingSubtitle, dynamicStyles.subtitleText]}>
                    {selectedLanguage.label}
                  </Text>
                </View>
              </View>
              <Text style={[styles.chevron, dynamicStyles.chevron]}>›</Text>
            </Pressable>
          </View>

          {/* Privacy & Security Section */}
          <View style={[styles.section, dynamicStyles.section]}>
            <Text style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>Privacy & Security</Text>
            
            <Pressable 
              style={[styles.settingItem, dynamicStyles.settingItem]} 
              onPress={showPrivacyAlert}
            >
              <View style={styles.settingLeft}>
                <View style={[styles.iconContainer, { backgroundColor: '#06b6d4' }]}>
                  <Text style={styles.iconText}>🛡️</Text>
                </View>
                <View style={styles.settingTextContainer}>
                  <Text style={[styles.settingTitle, dynamicStyles.text]}>Privacy Policy</Text>
                  <Text style={[styles.settingSubtitle, dynamicStyles.subtitleText]}>
                    View our privacy terms
                  </Text>
                </View>
              </View>
              <Text style={[styles.chevron, dynamicStyles.chevron]}>›</Text>
            </Pressable>
          </View>

          {/* Account Section */}
          <View style={[styles.section, dynamicStyles.section]}>
            <Text style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>Account</Text>
            
            <Pressable 
              style={[styles.settingItem, styles.logoutItem, dynamicStyles.settingItem]} 
              onPress={logout}
            >
              <View style={styles.settingLeft}>
                <View style={[styles.iconContainer, { backgroundColor: '#ef4444' }]}>
                  <Text style={styles.iconText}>🚪</Text>
                </View>
                <View style={styles.settingTextContainer}>
                  <Text style={[styles.settingTitle, styles.logoutText]}>Sign Out</Text>
                  <Text style={[styles.settingSubtitle, dynamicStyles.subtitleText]}>
                    Log out of your account
                  </Text>
                </View>
              </View>
              <Text style={[styles.chevron, { color: '#ef4444' }]}>›</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>

      {/* Logout Confirmation Modal */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={logoutModalVisible}
        onRequestClose={() => setLogoutModalVisible(false)}
      >
        <View style={dynamicStyles.modalBackground}>
          <View style={[dynamicStyles.modalContainer, styles.confirmModal]}>
            <View style={[styles.confirmIcon, { backgroundColor: '#10b981' }]}>
              <Text style={styles.confirmIconText}>✓</Text>
            </View>
            <Text style={dynamicStyles.modalHeaderText}>Success!</Text>
            <Text style={dynamicStyles.confirmText}>
              You have been logged out successfully.
            </Text>
            <Pressable
              style={[dynamicStyles.modalButton, { backgroundColor: '#10b981' }]}
              onPress={() => {
                setLogoutModalVisible(false);
                router.replace("/login");
              }}
            >
              <Text style={dynamicStyles.modalButtonText}>Continue</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function getDynamicStyles() {
  return StyleSheet.create({
    container: {
      backgroundColor: "#0f0f0f",
    },
    profileSection: {
      backgroundColor: "#1a1a1a",
    },
    avatarContainer: {
      shadowColor: "#10b981",
      shadowOpacity: 0.3,
    },
    avatar: {
      backgroundColor: "#10b981",
    },
    avatarText: {
      color: "#ffffff",
    },
    statusIndicator: {
      backgroundColor: "#10b981",
    },
    userName: {
      color: "#ffffff",
    },
    userEmail: {
      color: "#9ca3af",
    },
    settingsContainer: {
      backgroundColor: "#0f0f0f",
    },
    section: {
      backgroundColor: "#1a1a1a",
    },
    sectionTitle: {
      color: "#10b981",
    },
    settingItem: {
      backgroundColor: "#262626",
      borderColor: "#374151",
    },
    text: {
      color: "#ffffff",
    },
    subtitleText: {
      color: "#9ca3af",
    },
    chevron: {
      color: "#6b7280",
    },
    modalBackground: {
      backgroundColor: "rgba(0,0,0,0.8)",
    },
    modalContainer: {
      backgroundColor: "#1a1a1a",
      borderColor: "#374151",
    },
    modalHeaderText: {
      color: "#ffffff",
    },
    closeButton: {
      backgroundColor: "#374151",
    },
    closeButtonText: {
      color: "#9ca3af",
    },
    languageOption: {
      borderBottomColor: "#374151",
    },
    selectedLanguageOption: {
      backgroundColor: "#065f46",
    },
    languageText: {
      color: "#ffffff",
    },
    selectedLanguage: {
      color: "#10b981",
    },
    checkmark: {
      color: "#10b981",
    },
    modalButton: {
      backgroundColor: "#10b981",
    },
    modalButtonText: {
      color: "#ffffff",
    },
    privacySection: {
      backgroundColor: "transparent",
    },
    privacyText: {
      color: "#d1d5db",
    },
    confirmText: {
      color: "#9ca3af",
    },
  });
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 40,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 16,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 10 },
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 28,
    fontWeight: 'bold',
  },
  statusIndicator: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 3,
    borderColor: '#1a1a1a',
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 16,
    fontWeight: '500',
  },
  settingsContainer: {
    flex: 1,
    paddingTop: 20,
  },
  section: {
    marginHorizontal: 20,
    marginBottom: 24,
    borderRadius: 16,
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 1,
  },
  logoutItem: {
    marginBottom: 0,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  iconText: {
    fontSize: 20,
  },
  settingTextContainer: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 2,
  },
  settingSubtitle: {
    fontSize: 14,
    fontWeight: '400',
  },
  logoutText: {
    color: '#ef4444',
  },
  chevron: {
    fontSize: 24,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  switch: {
    transform: [{ scaleX: 1.1 }, { scaleY: 1.1 }],
  },
  modalBackground: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '90%',
    maxWidth: 400,
    borderRadius: 20,
    padding: 0,
    maxHeight: '80%',
    borderWidth: 1,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#374151',
  },
  modalHeaderText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  closeButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  languageOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
  },
  selectedLanguageOption: {
    borderRadius: 8,
    marginHorizontal: 8,
  },
  languageText: {
    fontSize: 16,
    fontWeight: '500',
  },
  checkmark: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  privacyContent: {
    flex: 1,
  },
  privacySection: {
    padding: 24,
  },
  privacyText: {
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 16,
  },
  confirmModal: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  confirmIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  confirmIconText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  modalButton: {
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 12,
    marginTop: 20,
    minWidth: 120,
    alignItems: 'center',
  },
});