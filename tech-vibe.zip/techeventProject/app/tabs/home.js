import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  ActivityIndicator,
  Alert,
  Linking,
  Platform,
  Dimensions,
  ImageBackground,
} from "react-native";
import { Ionicons, MaterialIcons, FontAwesome5 } from "@expo/vector-icons";
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

export default function Home() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setEvents([
        {
          id: "1",
          title: "Startup Networking Night",
          image: "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=800&q=80",
          location: "Melbourne, Docklands",
          time: "7:00 PM, June 1st",
          category: "Networking",
          attendees: "150+ attending",
          price: "Free",
          gradient: ['#667eea', '#764ba2'],
        },
        {
          id: "2",
          title: "Tech Innovation Conference",
          image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80",
          location: "Sydney Convention Center",
          time: "9:00 AM, July 10th",
          category: "Conference",
          attendees: "500+ attending",
          price: "$199",
          gradient: ['#f093fb', '#f5576c'],
        },
        {
          id: "3",
          title: "AI & Robotics Expo",
          image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=800&q=80",
          location: "Brisbane Expo Grounds",
          time: "10:00 AM, August 5th",
          category: "Exhibition",
          attendees: "1000+ attending",
          price: "$79",
          gradient: ['#4facfe', '#00f2fe'],
        },
        {
          id: "4",
          title: "Digital Marketing Summit",
          image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?auto=format&fit=crop&w=800&q=80",
          location: "Adelaide Convention Hall",
          time: "1:00 PM, September 15th",
          category: "Summit",
          attendees: "300+ attending",
          price: "$149",
          gradient: ['#43e97b', '#38f9d7'],
        },
      ]);
      setLoading(false);
    }, 1500);
  }, []);

  const openMapDirections = (address) => {
    const query = encodeURIComponent(address);
    const url = Platform.select({
      ios: `maps:0,0?q=${query}`,
      android: `geo:0,0?q=${query}`,
    });

    Linking.canOpenURL(url)
      .then((supported) => {
        if (!supported) {
          Alert.alert("Error", "Maps application is not available");
        } else {
          return Linking.openURL(url);
        }
      })
      .catch((err) => Alert.alert("Error", "Failed to open maps: " + err));
  };

  const getCategoryIcon = (category) => {
    switch (category.toLowerCase()) {
      case 'networking': return 'users';
      case 'conference': return 'microphone-alt';
      case 'exhibition': return 'cube';
      case 'summit': return 'mountain';
      default: return 'calendar-alt';
    }
  };

  if (loading) {
    return (
      <LinearGradient colors={['#0f0c29', '#302b63', '#24243e']} style={styles.loadingContainer}>
        <View style={styles.loadingContent}>
          <ActivityIndicator size="large" color="#00d4ff" />
          <Text style={styles.loadingText}>Loading Events...</Text>
          <View style={styles.loadingDots}>
            <View style={[styles.dot, { animationDelay: 0 }]} />
            <View style={[styles.dot, { animationDelay: 0.2 }]} />
            <View style={[styles.dot, { animationDelay: 0.4 }]} />
          </View>
        </View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient colors={['#0f0c29', '#302b63', '#24243e']} style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
        {/* Header Section */}
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <View>
              <Text style={styles.greeting}>Tech Events 🚀</Text>
              <Text style={styles.subheading}>Discover the future of technology</Text>
            </View>
            <TouchableOpacity style={styles.profileButton}>
              <LinearGradient colors={['#667eea', '#764ba2']} style={styles.profileGradient}>
                <Ionicons name="person" size={20} color="white" />
              </LinearGradient>
            </TouchableOpacity>
          </View>
          
          {/* Stats Section */}
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <FontAwesome5 name="calendar-check" size={16} color="#00d4ff" />
              <Text style={styles.statNumber}>24</Text>
              <Text style={styles.statLabel}>Events</Text>
            </View>
            <View style={styles.statItem}>
              <FontAwesome5 name="users" size={16} color="#ff6b6b" />
              <Text style={styles.statNumber}>2.5K</Text>
              <Text style={styles.statLabel}>Attendees</Text>
            </View>
            <View style={styles.statItem}>
              <FontAwesome5 name="map-marker-alt" size={16} color="#4ecdc4" />
              <Text style={styles.statNumber}>8</Text>
              <Text style={styles.statLabel}>Cities</Text>
            </View>
          </View>
        </View>

        {/* Events Section */}
        <View style={styles.eventsSection}>
          <Text style={styles.sectionTitle}>Upcoming Events</Text>
          {events.map((event, index) => (
            <View key={event.id} style={[styles.card, { marginTop: index === 0 ? 0 : 20 }]}>
              <ImageBackground source={{ uri: event.image }} style={styles.imageBackground}>
                <LinearGradient 
                  colors={['transparent', 'rgba(0,0,0,0.8)']} 
                  style={styles.imageOverlay}
                >
                  <View style={styles.categoryBadge}>
                    <FontAwesome5 name={getCategoryIcon(event.category)} size={12} color="white" />
                    <Text style={styles.categoryText}>{event.category}</Text>
                  </View>
                  <View style={styles.priceBadge}>
                    <Text style={styles.priceText}>{event.price}</Text>
                  </View>
                </LinearGradient>
              </ImageBackground>
              
              <View style={styles.cardContent}>
                <Text style={styles.cardTitle}>{event.title}</Text>
                
                <View style={styles.eventDetails}>
                  <View style={styles.detailRow}>
                    <Ionicons name="location-outline" size={16} color="#00d4ff" />
                    <Text style={styles.detailText}>{event.location}</Text>
                  </View>
                  
                  <View style={styles.detailRow}>
                    <MaterialIcons name="access-time" size={16} color="#ff6b6b" />
                    <Text style={styles.detailText}>{event.time}</Text>
                  </View>
                  
                  <View style={styles.detailRow}>
                    <FontAwesome5 name="users" size={14} color="#4ecdc4" />
                    <Text style={styles.detailText}>{event.attendees}</Text>
                  </View>
                </View>

                <View style={styles.buttonContainer}>
                  <TouchableOpacity
                    style={styles.directionsButton}
                    onPress={() => openMapDirections(event.location)}
                  >
                    <Ionicons name="navigate" size={16} color="#00d4ff" />
                    <Text style={styles.directionsButtonText}>Directions</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity style={styles.rsvpButton}>
                    <LinearGradient colors={event.gradient} style={styles.rsvpGradient}>
                      <Text style={styles.rsvpButtonText}>RSVP Now</Text>
                      <Ionicons name="arrow-forward" size={16} color="white" />
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          ))}
        </View>

        {/* Footer Spacing */}
        <View style={styles.footer} />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingContent: {
    alignItems: 'center',
  },
  loadingText: {
    color: '#fff',
    fontSize: 16,
    marginTop: 15,
    fontWeight: '500',
  },
  loadingDots: {
    flexDirection: 'row',
    marginTop: 10,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#00d4ff',
    marginHorizontal: 3,
  },
  
  // Header Styles
  header: {
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 25,
  },
  greeting: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#ffffff",
    marginBottom: 5,
  },
  subheading: {
    fontSize: 16,
    color: "#a0a9c0",
    fontWeight: '400',
  },
  profileButton: {
    marginTop: 5,
  },
  profileGradient: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  // Stats Styles
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 20,
    backdropFilter: 'blur(10px)',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#a0a9c0',
    fontWeight: '500',
  },
  
  // Events Section
  eventsSection: {
    paddingHorizontal: 20,
    paddingTop: 30,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 20,
  },
  
  // Card Styles
  card: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    overflow: "hidden",
    backdropFilter: 'blur(10px)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  imageBackground: {
    width: "100%",
    height: 200,
    justifyContent: 'space-between',
  },
  imageOverlay: {
    flex: 1,
    padding: 15,
    justifyContent: 'space-between',
  },
  categoryBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  categoryText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 6,
  },
  priceBadge: {
    backgroundColor: 'rgba(0,212,255,0.9)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
    alignSelf: 'flex-end',
  },
  priceText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  
  // Card Content
  cardContent: {
    padding: 20,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#ffffff",
    marginBottom: 15,
  },
  eventDetails: {
    marginBottom: 20,
  },
  detailRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  detailText: {
    color: "#a0a9c0",
    marginLeft: 10,
    fontSize: 14,
    fontWeight: '500',
  },
  
  // Button Styles
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  directionsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,212,255,0.2)',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#00d4ff',
  },
  directionsButtonText: {
    color: "#00d4ff",
    fontWeight: "600",
    fontSize: 14,
    marginLeft: 6,
  },
  rsvpButton: {
    flex: 1,
    marginLeft: 12,
  },
  rsvpGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 25,
  },
  rsvpButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
    marginRight: 8,
  },
  
  footer: {
    height: 40,
  },
});