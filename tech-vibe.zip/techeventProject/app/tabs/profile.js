import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  SafeAreaView,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Animated,
  Dimensions,
} from "react-native";
import { Ionicons, MaterialIcons, FontAwesome5 } from "@expo/vector-icons";
import { LinearGradient } from 'expo-linear-gradient';
import ApiService from "../../services/api";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";

const { width } = Dimensions.get('window');

export default function Profile() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [newHobby, setNewHobby] = useState("");
  const [newInterest, setNewInterest] = useState("");

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setLoading(true);
        setError(null);

        const token = await AsyncStorage.getItem('token');

        const response = await axios.get(ApiService.GET_USER_PROFILE, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = response.data;
        data.hobbies = data.hobbies || [];
        data.interests = data.interests || [];

        setUser(data);
      } catch (err) {
        setError(err.message || 'An error occurred');
      } finally {
        setLoading(false);
        Animated.parallel([
          Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 800,
            useNativeDriver: true,
          }),
          Animated.timing(slideAnim, {
            toValue: 0,
            duration: 800,
            useNativeDriver: true,
          })
        ]).start();
      }
    };

    fetchUserData();
  }, []);

  const addHobby = () => {
    if (!newHobby.trim()) return;
    setUser(prev => ({ ...prev, hobbies: [...prev.hobbies, newHobby.trim()] }));
    setNewHobby("");
  };

  const removeHobby = (index) => {
    setUser(prev => ({
      ...prev,
      hobbies: prev.hobbies.filter((_, i) => i !== index),
    }));
  };

  const addInterest = () => {
    if (!newInterest.trim()) return;
    setUser(prev => ({ ...prev, interests: [...prev.interests, newInterest.trim()] }));
    setNewInterest("");
  };

  const removeInterest = (index) => {
    setUser(prev => ({
      ...prev,
      interests: prev.interests.filter((_, i) => i !== index),
    }));
  };

  if (loading) {
    return (
      <LinearGradient colors={['#0f0c29', '#302b63', '#24243e']} style={styles.loadingContainer}>
        <View style={styles.loadingContent}>
          <ActivityIndicator size="large" color="#00d4ff" />
          <Text style={styles.loadingText}>Loading Profile...</Text>
          <View style={styles.loadingDots}>
            <View style={[styles.dot, { animationDelay: 0 }]} />
            <View style={[styles.dot, { animationDelay: 0.2 }]} />
            <View style={[styles.dot, { animationDelay: 0.4 }]} />
          </View>
        </View>
      </LinearGradient>
    );
  }

  if (error) {
    return (
      <LinearGradient colors={['#0f0c29', '#302b63', '#24243e']} style={styles.loadingContainer}>
        <View style={styles.errorContainer}>
          <Ionicons name="alert-circle" size={48} color="#ff6b6b" />
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryButton}>
            <LinearGradient colors={['#ff6b6b', '#ee5a52']} style={styles.retryGradient}>
              <Text style={styles.retryButtonText}>Retry</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    );
  }

  const ProfileInfoCard = ({ icon, label, value, iconColor }) => (
    <View style={styles.infoCard}>
      <View style={[styles.iconContainer, { backgroundColor: `${iconColor}20` }]}>
        <Ionicons name={icon} size={20} color={iconColor} />
      </View>
      <View style={styles.infoContent}>
        <Text style={styles.infoLabel}>{label}</Text>
        <Text style={styles.infoValue}>{value || "N/A"}</Text>
      </View>
    </View>
  );

  const TagItem = ({ item, onRemove, gradient }) => (
    <View style={styles.tagContainer}>
      <LinearGradient colors={gradient} style={styles.tagGradient}>
        <Text style={styles.tagText}>{item}</Text>
        <TouchableOpacity onPress={onRemove} style={styles.tagRemove}>
          <Ionicons name="close" size={14} color="white" />
        </TouchableOpacity>
      </LinearGradient>
    </View>
  );

  return (
    <LinearGradient colors={['#0f0c29', '#302b63', '#24243e']} style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
        <Animated.View 
          style={[
            styles.content,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }]
            }
          ]}
        >
          {/* Header Section */}
          <View style={styles.header}>
            <View style={styles.headerTop}>
              <View>
                <Text style={styles.greeting}>Profile 👤</Text>
                <Text style={styles.subheading}>Manage your personal information</Text>
              </View>
              <View style={styles.avatarContainer}>
                <LinearGradient colors={['#667eea', '#764ba2']} style={styles.avatarGradient}>
                  <Text style={styles.avatarText}>
                    {user?.username?.charAt(0)?.toUpperCase() || 'U'}
                  </Text>
                </LinearGradient>
              </View>
            </View>

            {/* Stats Section */}
            <View style={styles.statsContainer}>
              <View style={styles.statItem}>
                <FontAwesome5 name="heart" size={16} color="#ff6b6b" />
                <Text style={styles.statNumber}>{user?.hobbies?.length || 0}</Text>
                <Text style={styles.statLabel}>Hobbies</Text>
              </View>
              <View style={styles.statItem}>
                <FontAwesome5 name="star" size={16} color="#4ecdc4" />
                <Text style={styles.statNumber}>{user?.interests?.length || 0}</Text>
                <Text style={styles.statLabel}>Interests</Text>
              </View>
              <View style={styles.statItem}>
                <FontAwesome5 name="user-check" size={16} color="#00d4ff" />
                <Text style={styles.statNumber}>1</Text>
                <Text style={styles.statLabel}>Profile</Text>
              </View>
            </View>
          </View>

          {/* Profile Information Section */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Personal Information</Text>
            <View style={styles.infoGrid}>
              <ProfileInfoCard
                icon="mail"
                label="Email"
                value={user?.email}
                iconColor="#00d4ff"
              />
              <ProfileInfoCard
                icon="person"
                label="Username"
                value={user?.username}
                iconColor="#4ecdc4"
              />
              <ProfileInfoCard
                icon="call"
                label="Phone"
                value={user?.phone}
                iconColor="#ff6b6b"
              />
            </View>
          </View>

          {/* Hobbies Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>
                <FontAwesome5 name="heart" size={18} color="#ff6b6b" /> Hobbies
              </Text>
              <Text style={styles.sectionSubtitle}>Things you love to do</Text>
            </View>

            <View style={styles.tagsContainer}>
              {user.hobbies.length > 0 ? (
                user.hobbies.map((hobby, index) => (
                  <TagItem
                    key={index}
                    item={hobby}
                    onRemove={() => removeHobby(index)}
                    gradient={['#ff6b6b', '#ee5a52']}
                  />
                ))
              ) : (
                <View style={styles.emptyState}>
                  <FontAwesome5 name="heart" size={32} color="#444" />
                  <Text style={styles.emptyText}>No hobbies added yet</Text>
                </View>
              )}
            </View>

            <View style={styles.inputContainer}>
              <View style={styles.inputWrapper}>
                <TextInput
                  placeholder="Add a hobby..."
                  placeholderTextColor="#a0a9c0"
                  style={styles.input}
                  value={newHobby}
                  onChangeText={setNewHobby}
                  onSubmitEditing={addHobby}
                />
              </View>
              <TouchableOpacity onPress={addHobby} style={styles.addButton}>
                <LinearGradient colors={['#ff6b6b', '#ee5a52']} style={styles.addButtonGradient}>
                  <Ionicons name="add" size={20} color="white" />
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>

          {/* Interests Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>
                <FontAwesome5 name="star" size={18} color="#4ecdc4" /> Interests
              </Text>
              <Text style={styles.sectionSubtitle}>Topics that fascinate you</Text>
            </View>

            <View style={styles.tagsContainer}>
              {user.interests.length > 0 ? (
                user.interests.map((interest, index) => (
                  <TagItem
                    key={index}
                    item={interest}
                    onRemove={() => removeInterest(index)}
                    gradient={['#4ecdc4', '#44a08d']}
                  />
                ))
              ) : (
                <View style={styles.emptyState}>
                  <FontAwesome5 name="star" size={32} color="#444" />
                  <Text style={styles.emptyText}>No interests added yet</Text>
                </View>
              )}
            </View>

            <View style={styles.inputContainer}>
              <View style={styles.inputWrapper}>
                <TextInput
                  placeholder="Add an interest..."
                  placeholderTextColor="#a0a9c0"
                  style={styles.input}
                  value={newInterest}
                  onChangeText={setNewInterest}
                  onSubmitEditing={addInterest}
                />
              </View>
              <TouchableOpacity onPress={addInterest} style={styles.addButton}>
                <LinearGradient colors={['#4ecdc4', '#44a08d']} style={styles.addButtonGradient}>
                  <Ionicons name="add" size={20} color="white" />
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>

          {/* Footer Spacing */}
          <View style={styles.footer} />
        </Animated.View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  
  // Loading Styles
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingContent: {
    alignItems: 'center',
  },
  loadingText: {
    color: '#fff',
    fontSize: 16,
    marginTop: 15,
    fontWeight: '500',
  },
  loadingDots: {
    flexDirection: 'row',
    marginTop: 10,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#00d4ff',
    marginHorizontal: 3,
  },
  
  // Error Styles
  errorContainer: {
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  errorText: {
    color: '#ff6b6b',
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
    marginVertical: 20,
  },
  retryButton: {
    marginTop: 10,
  },
  retryGradient: {
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
  },
  retryButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  
  // Header Styles
  header: {
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 25,
  },
  greeting: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#ffffff",
    marginBottom: 5,
  },
  subheading: {
    fontSize: 16,
    color: "#a0a9c0",
    fontWeight: '400',
  },
  avatarContainer: {
    marginTop: 5,
  },
  avatarGradient: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  
  // Stats Styles
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 20,
    backdropFilter: 'blur(10px)',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#a0a9c0',
    fontWeight: '500',
  },
  
  // Section Styles
  section: {
    marginHorizontal: 20,
    marginBottom: 25,
  },
  sectionHeader: {
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 5,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#a0a9c0',
    fontWeight: '400',
  },
  
  // Info Grid Styles
  infoGrid: {
    gap: 12,
  },
  infoCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    backdropFilter: 'blur(10px)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  infoContent: {
    flex: 1,
  },
  infoLabel: {
    fontSize: 12,
    color: '#a0a9c0',
    fontWeight: '500',
    marginBottom: 4,
  },
  infoValue: {
    fontSize: 16,
    color: '#ffffff',
    fontWeight: '600',
  },
  
  // Tags Styles
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 20,
  },
  tagContainer: {
    marginRight: 10,
    marginBottom: 10,
  },
  tagGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  tagText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
    marginRight: 8,
  },
  tagRemove: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: 'rgba(255,255,255,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  // Empty State
  emptyState: {
    alignItems: 'center',
    paddingVertical: 30,
    width: '100%',
  },
  emptyText: {
    color: '#666',
    fontSize: 16,
    marginTop: 10,
    fontWeight: '500',
  },
  
  // Input Styles
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  inputWrapper: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  input: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '500',
  },
  addButton: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  addButtonGradient: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  footer: {
    height: 40,
  },
});