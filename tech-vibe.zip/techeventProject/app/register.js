import React, { useState } from "react";
import { Stack } from "expo-router";

import {
  View,
  Text,
  TextInput,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  Animated,
  Alert,
} from "react-native";
import { useRouter } from "expo-router";
import Icon from "react-native-vector-icons/Ionicons";
import ApiService from "../services/api";
import axios from "axios";

export default function Register() {
  const [scaleAnim] = useState(new Animated.Value(1));
  const router = useRouter();

  const [form, setForm] = useState({
    username: "",
    email: "",
    phone: "",
    password: "",
  });

  const handleChange = (name, value) => {
    setForm({ ...form, [name]: value });
  };

  // const onRegister = async () => {
  //   try {
  //     const response = await fetch("http://192.168.1.8:5000/api/user/register", {
  //       method: "POST",
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: JSON.stringify(form),
  //     });

  //     if (!response.ok) {
  //       const errorData = await response.json();
  //       Alert.alert("Registration Failed", errorData.message || "Unknown error");
  //       return;
  //     }

  //     const data = await response.json();
  //     Alert.alert("Success", "Registration successful! You can now login.");
  //     router.push("/login");
  //   } catch (error) {
  //     Alert.alert("Error", "Failed to connect to server: " + error.message);
  //   }
  // };


  const onRegister = async () => {
  try {
    const response = await axios.post(ApiService.USER_REGISTER, form);

    Alert.alert("Success", "Registration successful! You can now login.");
    router.push("/login");
  } catch (error) {
    if (error.response) {
      // Server responded with a status outside 2xx
      Alert.alert("Registration Failed", error.response.data.message || "Something went wrong");
    } else if (error.request) {
      // No response received
      Alert.alert("Error", "No response from server.");
    } else {
      // Other errors
      Alert.alert("Error", "Something went wrong: " + error.message);
    }
  }
};

  const onPressIn = () => {
    Animated.spring(scaleAnim, { toValue: 0.95, useNativeDriver: true }).start();
  };

  const onPressOut = () => {
    Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }).start();
  };

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.container}
      >
        <View style={styles.formCard}>
          <Text style={styles.title}>TechVibe ✨</Text>
          <Text style={styles.subtitle}>Create your account to get started</Text>

          <InputField
            icon="at-outline"
            placeholder="Username"
            value={form.username}
            onChangeText={(val) => handleChange("username", val)}
          />
          <InputField
            icon="mail-outline"
            placeholder="Email"
            keyboardType="email-address"
            value={form.email}
            onChangeText={(val) => handleChange("email", val)}
          />
          <InputField
            icon="call-outline"
            placeholder="Phone"
            keyboardType="phone-pad"
            value={form.phone}
            onChangeText={(val) => handleChange("phone", val)}
          />
          <InputField
            icon="lock-closed-outline"
            placeholder="Password"
            secureTextEntry
            value={form.password}
            onChangeText={(val) => handleChange("password", val)}
          />

          <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
            <Pressable
              onPress={onRegister}
              onPressIn={onPressIn}
              onPressOut={onPressOut}
              style={styles.button}
            >
              <Text style={styles.buttonText}>Register</Text>
            </Pressable>
          </Animated.View>

          <Pressable onPress={() => router.push("/login")}>
            <Text style={styles.linkText}>Already have an account? Login</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </>
  );
}

const InputField = ({ icon, ...props }) => (
  <View style={styles.inputWrapper}>
    <Icon name={icon} size={22} color="#94a3b8" style={styles.icon} />
    <TextInput placeholderTextColor="#cbd5e1" style={styles.input} {...props} />
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0f172a",
    justifyContent: "center",
    paddingHorizontal: 20,
  },
  formCard: {
    backgroundColor: "#1e293b",
    padding: 25,
    borderRadius: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 12,
  },
  title: {
    fontSize: 38,
    fontWeight: "bold",
    color: "#0ea5e9",
    textAlign: "center",
    marginBottom: 10,
    fontFamily: Platform.OS === "ios" ? "HelveticaNeue-Bold" : "Roboto-Bold",
  },
  subtitle: {
    fontSize: 16,
    color: "#94a3b8",
    textAlign: "center",
    marginBottom: 30,
    fontFamily: Platform.OS === "ios" ? "HelveticaNeue" : "Roboto",
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#334155",
    borderRadius: 12,
    paddingHorizontal: 12,
    marginBottom: 18,
  },
  icon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    color: "white",
    fontSize: 16,
    paddingVertical: 12,
    fontFamily: Platform.OS === "ios" ? "HelveticaNeue" : "Roboto",
  },
  button: {
    backgroundColor: "#0ea5e9",
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
    marginBottom: 20,
  },
  buttonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "600",
    fontFamily: Platform.OS === "ios" ? "HelveticaNeue" : "Roboto",
  },
  linkText: {
    color: "#38bdf8",
    textAlign: "center",
    fontSize: 15,
    marginTop: 10,
    fontFamily: Platform.OS === "ios" ? "HelveticaNeue" : "Roboto",
  },
});
