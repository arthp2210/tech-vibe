import { useEffect } from "react";
import { View, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function Index() {
  const router = useRouter();

  useEffect(() => {
    let isMounted = true; // To prevent state update if unmounted

    async function checkLogin() {
      try {
        const token = await AsyncStorage.getItem("userToken");
        if (isMounted) {
          router.replace(token ? "/tabs/home" : "/login");
        }
      } catch (error) {
        if (isMounted) {
          router.replace("/login");
        }
      }
    }

    checkLogin();

    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "#0f172a" }}>
      <ActivityIndicator size="large" color="#0ea5e9" />
    </View>
  );
}
