import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  Animated,
  Alert,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter, Stack } from "expo-router";
import ApiService from "../services/api";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [hovered, setHovered] = useState(false);
  const scaleAnim = new Animated.Value(1);
  const router = useRouter();

  const onLogin = async () => {
  if (!email || !password) {
    Alert.alert("Error", "Please enter email and password");
    return;
  }

  try {
    const response = await fetch(ApiService.USER_LOGIN, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();

    if (!response.ok) {
      Alert.alert("Login Failed", data.message || "Something went wrong");
      return;
    }

    // Save the JWT token in AsyncStorage
    await AsyncStorage.setItem("token", data.token);
    await AsyncStorage.setItem("isLoggedIn", "true");

    // Save user info as a JSON string
  await AsyncStorage.setItem("userInfo", JSON.stringify(data.user));

    Alert.alert("Success", "Login Successful!");

    setEmail("");
    setPassword("");

    // Navigate to home
    router.replace("/tabs/home");
  } catch (error) {
    Alert.alert("Error", "Network error. Please try again.");
    console.error("Login error:", error);
  }
};


  const onPressIn = () => {
    Animated.spring(scaleAnim, { toValue: 0.96, useNativeDriver: true }).start();
  };

  const onPressOut = () => {
    Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }).start();
  };

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.container}
      >
        <View style={styles.formCard}>
          <Text style={styles.welcome}>Welcome to TechVibe!</Text>
          <Text style={styles.title}>TechVibe 🚀</Text>
          <Text style={styles.subtitle}>Hackathons | Startups | Events</Text>

          <TextInput
            placeholder="Email"
            placeholderTextColor="#cbd5e1"
            style={styles.input}
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
          />
          <TextInput
            placeholder="Password"
            placeholderTextColor="#cbd5e1"
            style={styles.input}
            secureTextEntry
            value={password}
            onChangeText={setPassword}
          />

          <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
            <Pressable
              onPress={onLogin}
              onPressIn={onPressIn}
              onPressOut={onPressOut}
              onHoverIn={() => setHovered(true)}
              onHoverOut={() => setHovered(false)}
              style={[styles.button, hovered && { backgroundColor: "#0284c7" }]}
            >
              <Text style={styles.buttonText}>Login</Text>
            </Pressable>
          </Animated.View>

          <Pressable onPress={() => router.push("/register")}>
            <Text style={styles.linkText}>Don't have an account? Register</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0f172a",
    justifyContent: "center",
    paddingHorizontal: 20,
  },
  formCard: {
    backgroundColor: "#1e293b",
    padding: 25,
    borderRadius: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 12,
  },
  welcome: {
    fontSize: 20,
    color: "#f1f5f9",
    textAlign: "center",
    marginBottom: 10,
    fontWeight: "500",
  },
  title: {
    fontSize: 36,
    fontWeight: "bold",
    color: "#0ea5e9",
    textAlign: "center",
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: "#94a3b8",
    textAlign: "center",
    marginBottom: 30,
  },
  input: {
    backgroundColor: "#334155",
    color: "white",
    padding: 15,
    borderRadius: 12,
    fontSize: 16,
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#0ea5e9",
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: "center",
    marginBottom: 20,
  },
  buttonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "600",
  },
  linkText: {
    color: "#38bdf8",
    textAlign: "center",
    fontSize: 15,
    marginTop: 10,
  },
});
