const API_BASE_URL = 'https://tech-final.vercel.app/api';

const ApiService = {
  // AUTH
  USER_LOGIN: `${API_BASE_URL}/user/login`,
  USER_REGISTER: `${API_BASE_URL}/user/register`,

  // EVENTS
  GET_EVENTS: `${API_BASE_URL}/event`,
  POST_EVENT: `${API_BASE_URL}/event`,

  // RSVP
  POST_RSVP: `${API_BASE_URL}/rsvp`,

  // USER PROFILE
  GET_USER_PROFILE: `${API_BASE_URL}/user/profile`,
};

export default ApiService;
